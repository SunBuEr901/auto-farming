# Robot Documentation Governance Skill

A reusable governance package for an AI-Agent-maintained unmanned farming vehicle documentation repository.

## Install

Copy this folder into your project repository, for example:

```text
repo/
├── AGENTS.md
├── SKILL.md
├── rules/
└── templates/
```

You may also place it under a dedicated path such as:

```text
.agent/skills/robot-doc-governance/
```

Then ensure your Agent entry instructions explicitly require reading `SKILL.md` before any repository write operation.

## First Setup

1. Edit `rules/MODEL_POLICY.md`.
2. Replace `TO_BE_SPECIFIED` with the project's approved high-capability model.
3. Decide whether credentials may be stored in plaintext in the private repository.
4. Adjust template metadata fields if needed.
5. Add repository-specific paths to `SKILL.md` if your layout differs.

## Recommended Repository Structure

```text
README.md
CURRENT_STATUS.md
CHANGELOG.md
AGENTS.md
SKILL.md
rules/
templates/
docs/
logs/
experiments/
scratch/
inventory/
configs/
scripts/
private/
```

## Design Goal

A future maintainer should be able to determine:

- what is currently true;
- what is uncertain;
- how each important fact was obtained;
- how to operate the vehicle safely;
- what changed over time;
- why important engineering decisions were made.

# AGENTS.md

All AI Agents operating in this repository must follow `SKILL.md` and all files under `rules/`.

## Mandatory rules

1. Use only the project-designated high-capability model for write operations.
2. Never silently downgrade models.
3. Never write inference as current vehicle fact.
4. Preserve traceability of important engineering information.
5. Use repository templates for new formal documents.
6. Put experiments and failed attempts in logs/experiments, not formal operation guides.
7. Update current-state documents only with confirmed information.
8. Keep uncertain values explicitly marked `UNVERIFIED` or `UNKNOWN`.
9. Do not fabricate passwords, IPs, versions, hardware models, ROS information, ports, dimensions, or parameters.
10. For high-risk procedures, include verification and rollback instructions.

If these rules conflict with a task request, do not silently violate them. Record the conflict or ask for project-owner direction when appropriate.

# Agent Write Workflow

Use this workflow for formal repository writes.

## 1. Classify the task

Choose one or more:

- current status update
- operation guide
- troubleshooting
- engineering log
- hardware inventory
- software inventory
- architecture decision
- credential record
- configuration documentation
- repository maintenance

## 2. Identify evidence

For each important factual statement, determine its source.

## 3. Assign trust level

Use:

- VERIFIED
- SOURCED
- UNVERIFIED
- UNKNOWN
- DEPRECATED
- INCORRECT

## 4. Select destination

- Current confirmed fact -> formal docs / CURRENT_STATUS
- Experiment -> logs/ or experiments/
- Temporary note -> scratch/
- Historical decision -> ADR / CHANGELOG
- Secret/credential -> private/ according to credential policy

## 5. Write using a template

Use a matching file under `templates/`.

## 6. Validate

Check:

- no fabricated values;
- source and verification status are clear;
- commands are distinguished between tested and untested;
- high-risk steps have rollback/recovery;
- old and current states are separated;
- model policy was followed.

## 7. Update related records

When appropriate, update:

- CURRENT_STATUS.md
- CHANGELOG.md
- logs/
- inventory/
- configs/

## 8. Commit clearly

Use a concise commit message describing the actual change.

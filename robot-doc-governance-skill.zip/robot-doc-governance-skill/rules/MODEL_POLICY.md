# Model Policy

## Designated write model

`TO_BE_SPECIFIED`

Replace the value above when the project selects its standard model.

## Policy

Repository write-capable Agents must use the designated model or another model explicitly approved at the same or higher capability tier.

Unapproved fallbacks are forbidden.

Examples of forbidden fallback categories:

- mini
- nano
- lite
- economy
- low-parameter local models
- low-cost automatic fallback models

If the designated model is unavailable:

- formal documentation writes must stop; or
- output must be written only to a clearly labeled draft/unverified area.

The Agent must not claim that a lower model is equivalent merely because the task appears simple.

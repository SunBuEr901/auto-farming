# Data Integrity Rules

## Principle

The main branch represents the best-known trusted state of the project.

## Rules

- Do not record guesses as facts.
- Do not copy AI-generated technical values into formal docs without evidence.
- Do not treat vendor defaults as observed configuration.
- Record source or verification method for critical values.
- Mark uncertain data clearly.
- Keep historical state separate from current state.
- Preserve meaningful change history.
- Do not delete useful historical evidence merely to make files look cleaner.
- Prefer `UNKNOWN` over a plausible fabricated value.
- Prefer explicit dates for volatile information.

## Critical fields requiring special care

- hostnames
- IP addresses
- usernames/passwords
- software versions
- ROS distro/version
- ROS nodes/topics/services/actions
- ports
- baud rates
- serial device paths
- GPIO mappings
- calibration values
- mechanical dimensions
- battery parameters
- sensor models
- hardware revisions
- startup services

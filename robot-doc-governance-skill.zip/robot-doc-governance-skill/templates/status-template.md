---
status: VERIFIED
last_verified: YYYY-MM-DD
verified_on: <vehicle/device>
source: <verification method>
---

# Current Status

## Hardware

| Item | Current State | Trust | Last Verified | Source |
|---|---|---|---|---|
| <item> | <value> | VERIFIED | YYYY-MM-DD | <source> |

## Software

| Item | Current State | Trust | Last Verified | Source |
|---|---|---|---|---|
| <item> | <value> | VERIFIED | YYYY-MM-DD | <source> |

## Connectivity

- SSH: <state>
- Remote Desktop: <state>
- Network: <state>

## Verified Capabilities

- [ ] <capability>

## Known Problems

### <Problem>

Status: <OPEN / RESOLVED / MONITORING>

Evidence:

<details>

## Next Work

- [ ] <task>

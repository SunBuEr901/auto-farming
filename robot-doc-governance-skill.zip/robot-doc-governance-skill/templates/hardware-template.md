---
status: UNVERIFIED
last_verified: null
source: null
---

# <Hardware Name>

## Identity

| Field | Value | Trust | Source |
|---|---|---|---|
| Model | <value> | UNKNOWN | <source> |
| Revision | <value> | UNKNOWN | <source> |
| Serial | <value> | UNKNOWN | <source> |

## Role

<What this hardware does in the vehicle.>

## Connections

| Interface | Connected To | Notes |
|---|---|---|
| <port> | <device> | <notes> |

## Parameters

| Parameter | Value | Unit | Trust | Source |
|---|---:|---|---|---|
| <parameter> | <value> | <unit> | UNKNOWN | <source> |

## Software Dependencies

- <dependency>

## Known Issues

- <issue>

## Verification Procedure

<how to confirm identity/state>

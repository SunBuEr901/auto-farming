---
status: UNVERIFIED
last_verified: null
verified_on: null
---

# Troubleshooting: <Problem>

## Symptoms

- <symptom>

## Scope

<Which device/software/configuration this applies to.>

## Confirmed Causes

### Cause 1

Evidence:

<evidence>

## Diagnostic Steps

```bash
<command>
```

Expected:

```text
<expected output>
```

## Fix

<confirmed fix>

## Verification After Fix

```bash
<verification command>
```

## Recovery / Rollback

<recovery instructions>

## Unverified Hypotheses

- <hypothesis clearly marked as unverified>

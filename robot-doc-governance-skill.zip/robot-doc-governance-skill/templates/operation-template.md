---
status: UNVERIFIED
last_verified: null
verified_on: null
source: null
---

# <Operation Name>

## Purpose

<What this operation accomplishes.>

## Preconditions

- <condition>

## Procedure

### 1. <Step>

```bash
<command>
```

## Expected Result

```text
<expected output or state>
```

## Verification

```bash
<verification command>
```

## Risks

- <risk>

## Rollback / Recovery

```bash
<rollback command or recovery steps>
```

## Known Issues

- <issue>

## References

- <source>

# Change Record — YYYY-MM-DD

## Summary

<what changed>

## Previous State

<old state>

## New State

<new state>

## Reason

<why>

## Evidence

<how the change was verified>

## Files Updated

- <file>

## Rollback

<if applicable>

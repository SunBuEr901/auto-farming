# Credential Record

> Store only according to repository access policy.

## System

- Name: <system>
- Purpose: <purpose>
- Environment: <device/service>

## Credential

- Username: <username>
- Password / Secret: <value or encrypted-storage reference>
- Last Confirmed: YYYY-MM-DD
- Confirmed By: <source/person/device>

## Risk Classification

`LOW / MEDIUM / HIGH`

## Storage Decision

<why this credential is stored here or elsewhere>

## Rotation / Recovery

<how to change/recover it>

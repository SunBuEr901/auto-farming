# Engineering Log — YYYY-MM-DD

## Objective

<What are we trying to learn or change?>

## Starting State

<Confirmed starting state.>

## Actions

### Attempt 1

<steps / commands / observations>

Result:

<result>

### Attempt 2

<steps / commands / observations>

Result:

<result>

## Evidence

```text
<command output / measurements / screenshots reference>
```

## Conclusion

<What is actually known now?>

## Trust Level

`VERIFIED / SOURCED / UNVERIFIED / UNKNOWN`

## Changes Promoted to Formal Documentation

- <file>

## Follow-up

- [ ] <next task>

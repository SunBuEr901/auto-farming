# ADR-XXXX: <Decision Title>

Date: YYYY-MM-DD

Status: Proposed / Accepted / Superseded / Deprecated

## Context

<Why a decision is needed.>

## Options Considered

1. <option>
2. <option>
3. <option>

## Decision

<chosen option>

## Rationale

<why>

## Consequences

### Benefits

- <benefit>

### Costs / Risks

- <risk>

## Evidence / References

- <source>

## Supersedes / Superseded By

<ADR reference if applicable>

# Robot Documentation Governance Skill

## Purpose

This skill governs how AI Agents create, modify, verify, and maintain the digital documentation repository for the unmanned farming vehicle project.

The repository is treated as a long-term engineering record and a Single Source of Truth (SSOT). Information merged into the main branch should be traceable, understandable, and appropriately verified.

## Core Principle

> High-capability models maintain knowledge; reliable data sources determine facts.

An Agent may organize, rewrite, summarize, migrate, and maintain trusted information, but must not invent current device facts.

## Scope

This skill applies to:

- Project documentation
- Current vehicle status
- Hardware and software inventory
- Operation guides
- Troubleshooting guides
- Configuration documentation
- Engineering logs
- Architecture decisions
- Credential records
- Change records
- Agent-authored repository maintenance

## Required Model Policy

Any Agent with write access MUST use the project-designated high-capability model.

The designated model is defined in:

`rules/MODEL_POLICY.md`

Agents MUST NOT silently downgrade to a smaller, lite, mini, nano, economy, or otherwise unapproved model.

If the designated model is unavailable, the Agent must either:

1. stop the write operation; or
2. write only to an explicitly marked draft/unverified area.

## Trust Levels

Every important piece of repository information should be considered one of the following:

- `VERIFIED` — confirmed on the actual vehicle/device or by an authoritative project source.
- `SOURCED` — supported by a credible source, but not yet verified on the actual vehicle.
- `UNVERIFIED` — plausible but not confirmed.
- `UNKNOWN` — currently unknown.
- `DEPRECATED` — previously valid but no longer current.
- `INCORRECT` — confirmed incorrect and retained only for historical context.

Do not convert a lower-trust item to `VERIFIED` without evidence.

## Allowed Agent Actions

Agents MAY directly:

- restructure documentation;
- summarize verified logs;
- normalize formatting;
- create cross-links;
- extract current facts from trusted repository records;
- update indexes;
- move confirmed information into formal documentation;
- create new documentation from user-confirmed or machine-verified data;
- update changelogs after confirmed changes.

## Forbidden Agent Actions

Agents MUST NOT:

- invent hardware models;
- invent IP addresses;
- invent passwords or credentials;
- assume ROS topics, nodes, ports, baud rates, GPIO mappings, dimensions, calibration values, software versions, or service states;
- treat vendor defaults as the current vehicle configuration without confirmation;
- present internet knowledge as observed device state;
- overwrite uncertain information with a guess;
- silently delete historical engineering information;
- silently downgrade the required model.

## Source Priority

Prefer evidence in this order:

1. Direct readout from the current vehicle/device.
2. Project-maintained verified records.
3. User/project-member explicit confirmation.
4. Physical label, purchase record, or official configuration file.
5. Official vendor documentation matched to the exact hardware revision.
6. External technical sources.
7. Model prior knowledge.

Items from levels 6–7 should normally remain `SOURCED` or `UNVERIFIED` until confirmed.

## Formal Documentation vs Experimental Records

Formal documentation should contain conclusions and currently valid procedures.

Experimental material belongs in:

- `logs/`
- `experiments/`
- `scratch/`

A failed attempt may remain in logs, but should not pollute the final operation guide.

## Repository Purity Rules

Before writing to formal documentation, ask:

1. What exactly is this information?
2. Where did it come from?
3. Is it current?
4. Is it verified?
5. Could a future maintainer distinguish fact from inference?
6. Does it belong in formal docs, logs, configuration, or history?

If the answer is unclear, do not write it as a current fact.

## Required Metadata for Important Documents

Use the following metadata where practical:

```yaml
status: VERIFIED
last_verified: YYYY-MM-DD
verified_on: <device/platform>
source: <source or verification method>
owner: <optional>
```

## High-Risk Changes

For documentation involving any of the following, include stronger verification and recovery guidance:

- motor control;
- battery or power systems;
- GPIO output;
- motion control;
- system services;
- kernel/driver changes;
- network core configuration;
- SSH/authentication configuration;
- startup services;
- destructive scripts;
- permission changes.

High-risk procedure documentation should include:

- prerequisites;
- exact steps;
- expected result;
- verification method;
- risk notes;
- rollback/recovery method.

## Credentials Policy

Credentials may be documented because this repository serves as a full digital equipment archive, but they must be handled intentionally.

Use:

- `private/credentials.md` for low/medium-risk project-local credentials if the repository access model permits it;
- encrypted storage or an external secrets manager for high-value tokens, personal accounts, cloud credentials, or API keys.

Never fabricate missing credentials.

## Commit Guidance

Important Agent commits should explain:

- what changed;
- why it changed;
- source of the information;
- verification status when relevant.

Recommended commit prefixes:

- `docs:` documentation update
- `status:` current-state update
- `log:` engineering log
- `fix:` corrected wrong documentation
- `config:` configuration change
- `adr:` architecture decision
- `agent:` Agent maintenance

## When Updating Current State

When a confirmed device change occurs, check whether the following need updates:

- `CURRENT_STATUS.md`
- `CHANGELOG.md`
- corresponding `docs/` page
- `inventory/`
- `configs/`
- `logs/`

Do not update unrelated files merely for cosmetic consistency.

## Templates

Use the templates in `templates/` instead of creating arbitrary formats.

Available templates:

- `operation-template.md`
- `status-template.md`
- `engineering-log-template.md`
- `troubleshooting-template.md`
- `hardware-template.md`
- `adr-template.md`
- `credential-template.md`
- `change-template.md`

## Final Validation Before Write/Merge

Before finishing a write task, verify:

- No guesses are presented as facts.
- Important facts have a source or verification method.
- Uncertainty is explicitly labeled.
- Current state and historical state are not mixed.
- Experimental attempts are not copied into formal guides without cleanup.
- No unintended model downgrade occurred.
- High-risk operations have validation and recovery instructions.
- Links and referenced files are valid when practical.
- The resulting document is useful to a future maintainer with no conversation context.
